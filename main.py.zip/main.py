# Seekr - By: aaron - Sat Apr 19 2025

import sensor
import time
import math

from machine import PWM
from machine import Pin



GRAYSCALE_THRESHOLD = [(20,130)]
p7 = PWM("P7", freq=50, duty_u16=6553)
p7.init(freq=50, duty_ns=1500000)


#Declare GPIO Pins
GPIO0 = Pin(0, Pin.OUT)
GPIO1 = Pin(1, Pin.OUT)
GPIO2 = Pin(2, Pin.OUT)
GPIO3 = Pin(3, Pin.OUT)
GPIO4 = Pin(4, Pin.OUT)


sensor.reset()
sensor.set_pixformat(sensor.GRAYSCALE)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time=2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
clock = time.clock()


ROI1 = (54, 30, 20, 20)
ROI2 = (96, 30, 20, 20)
ROI3 = (50, 86, 20, 20)
ROI4 = (100, 80, 20, 20)


while True:
    GPIO4.value(0)
    clock.tick()
    img = sensor.snapshot()

    blackTape1 = img.find_blobs(GRAYSCALE_THRESHOLD, roi=ROI1, merge=True)
    blackTape1 = [b for b in blackTape1 if b.pixels() > 20]
    if blackTape1:
        centerTape1 = min(blackTape1, key=lambda b: math.fabs(b.cx() - 90))
        img.draw_rectangle(centerTape1.rect(), color = 255)
        img.draw_cross(centerTape1.cx(), centerTape1.cy(), color = 255)
        GPIO0.value(1)
    else:
        print("No Tape1 Detected")
        GPIO0.value(0)


    blackTape2 = img.find_blobs(GRAYSCALE_THRESHOLD, roi=ROI2, merge=True)
    blackTape2 = [b for b in blackTape2 if b.pixels() > 20]
    if blackTape2:
        centerTape2 = min(blackTape2, key=lambda b: math.fabs(b.cx() - 90))
        img.draw_rectangle(centerTape2.rect(), color = 255)
        img.draw_cross(centerTape2.cx(), centerTape2.cy(), color = 255)
        GPIO1.value(1)
    else:
        print("No Tape2 Detected")
        GPIO1.value(0)


    blackTape3 = img.find_blobs(GRAYSCALE_THRESHOLD, roi=ROI3, merge=True)
    blackTape3 = [b for b in blackTape3 if b.pixels() > 20]
    if blackTape3:
        centerTape3 = min(blackTape3, key=lambda b: math.fabs(b.cx() - 90))
        img.draw_rectangle(centerTape3.rect(), color = 255)
        img.draw_cross(centerTape3.cx(), centerTape3.cy(), color = 255)
        GPIO2.value(1)
    else:
        print("No Tape3 Detected")
        GPIO2.value(0)


    blackTape4 = img.find_blobs(GRAYSCALE_THRESHOLD, roi=ROI4, merge=True)
    blackTape4 = [b for b in blackTape4 if b.pixels() > 20]
    if blackTape4:
        centerTape4 = min(blackTape4, key=lambda b: math.fabs(b.cx() - 90))
        img.draw_rectangle(centerTape4.rect(), color = 255)
        img.draw_cross(centerTape4.cx(), centerTape4.cy(), color = 255)
        GPIO3.value(1)
    else:
        print("No Tape4 Detected")
        GPIO3.value(0)


    # Puzzle is complete.
    if (blackTape1 and blackTape2 and blackTape3 and blackTape4):
        GPIO4.value(1)
        time.sleep(5)
        GPIO4.value(0)